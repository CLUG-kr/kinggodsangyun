package com.example.ocksangyun.map_fix;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceActivity;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Setting extends PreferenceActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.layout.preference);

            final List<String> ListItems = new ArrayList<>();
            ListItems.add("5분");
            ListItems.add("10분");
            ListItems.add("20분");
            ListItems.add("사용자 설정");
            final CharSequence[] items =  ListItems.toArray(new String[ ListItems.size()]);
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("시간을 선택하세요");
            builder.setItems(items, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int pos) {
                    String selectedText = items[pos].toString()+" 선택되었습니다";
                    Toast.makeText(Setting.this, selectedText, Toast.LENGTH_SHORT).show();
                }
            });
            builder.show();

    }
}
